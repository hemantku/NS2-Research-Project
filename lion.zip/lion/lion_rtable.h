#ifndef __lion_rtable_h__
#define __lion_rtable_h__

 #include <trace.h>
 #include <map>

struct entry
{
nsaddr_t src;
nsaddr_t dest;
int hop;
int cat_;//cat_ is the variable used to identify which type of node or category
int t;//status of the link
double x;
double y;
nsaddr_t nhop;
double dist;
double time;
int key;
};

struct rtable_t
{
entry ent[12000];
int count;
};



//typedef std::map<nsaddr_t, nsaddr_t> rtable_t;

 class lion_rtable {

     rtable_t rt_;

 public:
        lion_rtable();
        void       print(_IO_FILE*);
        void       clear();
    // void       rm_entry(nsaddr_t);
  void       add_entry(nsaddr_t,nsaddr_t,int,double,double,double,double,int,int,nsaddr_t);
        double   lookup(nsaddr_t);
	nsaddr_t ret_node(int);
	int ret_count();
	int retmatch(nsaddr_t);
	void add_ackentry(nsaddr_t,int,int);
        void send_lion_path();
     double distance(double,double,double,double);
     u_int32_t size();
	int space_L2link(nsaddr_t);
	int space_nolink(nsaddr_t);
	void check_valid(nsaddr_t,nsaddr_t,nsaddr_t,int);
	int node_with1key(nsaddr_t);
	void check_1keymatch(nsaddr_t,nsaddr_t[],int);
	void updatetable(nsaddr_t,nsaddr_t,nsaddr_t,int);
	void total_keys(nsaddr_t);
void   check_L2node(nsaddr_t,nsaddr_t[],int);
void  check_gateway(nsaddr_t,nsaddr_t[],int);
int verify_link(nsaddr_t);
 };
			
 #endif
