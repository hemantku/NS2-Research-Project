#ifndef __lion_pkt_h__
#define __lion_pkt_h__
#define L2K 600
#define L1K 30
#define GK 1000
#include <packet.h>
#define HDR_lion_PKT(p) hdr_lion_pkt::access(p)

  
 struct hdr_lion_pkt {
	nsaddr_t	pkt_src;
	nsaddr_t	pkt_des;
	nsaddr_t	send_addr[8];
	nsaddr_t        verify_addr[2][8];
	int		number_1key;
	int             matchno;
	double          pkt_x_;
        double          pkt_y_; 
	int		pkt_seq_num;
	nsaddr_t	pkt_hop; 
	int             ret; 
	int             type_;
 	int             category_;
	int             keyident[L2K];
	int             key;
	int             number_nolink;
	int 		number_L2node; 
	int             pkt_len; 		
	static int 	offset_;
	inline static int& offset() { return offset_; }
	inline static hdr_lion_pkt* access(const Packet* p) {
	return (hdr_lion_pkt*)p->access(offset_);
     }

 };

#endif
