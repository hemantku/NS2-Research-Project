#include <object.h>
#include <agent.h>
#include <trace.h>
#include <packet.h>
#include <scheduler.h>
#include <random.h>
#include <address.h>
#include <mac.h>
#include <ll.h>
#include <classifier-port.h>
#include <packet.h>
#include "lion.h"
#include  "lion_pkt.h"
#include  "lion_rtable.h"
#include <math.h>
#include <string.h>
#define L2K 600
#define L1K 30
#define GK 1000

//int ck[75];
//int match=0;
int some=0;
int globalkey[GK];
int cdlink=0;
int cindlink=0;

int hdr_lion_pkt::offset_;
static class lionHeaderClass : public PacketHeaderClass {
public:
lionHeaderClass() : PacketHeaderClass("PacketHeader/lion",sizeof(hdr_lion_pkt)) {
        bind_offset(&hdr_lion_pkt::offset_);
}
}class_lion_hdr;
  

static class lionClass : public TclClass {
public:
     lionClass() : TclClass("Agent/lion") {}
     TclObject* create(int argc, const char*const* argv) {
	assert(argc == 5);
	return (new lion((nsaddr_t)atoi(argv[4])));
     }
}class_lion;



void
lion_PktTimer::expire(Event* e) {
     agent_->send_lion_hello();
     //agent_->reset_lion_pkt_timer();
 }


lion::lion(nsaddr_t id) : Agent(PT_LION), pkt_timer_(this){
ra_addr()=id;
bind("x_",&x_);
bind("y_",&y_);
bind("category",&category_);
    
}
/*void lion::show_category()
{
printf("category=%d",category()); 
}*/

int lion::command(int argc, const char*const* argv) {
      if (argc == 2) {

          if (strcmp(argv[1], "start") == 0) {
              //printf("Starting our simulation");
              pkt_timer_.resched(0.0);
	      //show_category();
              return TCL_OK;
	      
          }
	else if(strcmp(argv[1],"deploy")==0) {
		global_deploy();
		return TCL_OK;	
	
	}	
	else if(strcmp(argv[1],"localkeydeploy")==0) {
		assignkey();
		return TCL_OK;
	}
	/*else if(strcmp(argv[1],"lionhello")==0) {
		send_lion_hello();
		return TCL_OK;
	}*/
	else if(strcmp(argv[1],"lionpkt")==0) {
		send_lion_pkt();
		return TCL_OK;
	}
	else if(strcmp(argv[1],"sumkeys")==0) {
		sum_keys();
		return TCL_OK;
	}
	else if(strcmp(argv[1],"lion1path")==0) {
		send_lion1path();
		return TCL_OK;
	}
	else if(strcmp(argv[1],"lionpath")==0) {
		send_lion_path();
		return TCL_OK;	
	}
	
	
	else if (strcasecmp(argv[1], "print_rtable") == 0) {
              printf("Routing table of=%d\n",ra_addr());  
              
                fprintf(stdout, " %f _%d_ Routing Table\t",
                     CURRENT_TIME,
                     ra_addr());
            	      rtable_.print(stdout);
			//show_category();
              return TCL_OK;
          }
	

	/*else if(strcmp(argv[1],"send_froml2")==0) {
		send_froml2();
		return TCL_OK;	
	}*/	
	
/*	  else {
           fprintf(stdout, "If you want to print this routing table "
                    "you must create a trace file in your tcl script");
             return TCL_OK;
         }*/

	
     }
     else if (argc == 3) {
         // Obtains corresponding dmux to carry packets to upper layers
         if (strcmp(argv[1], "port-dmux") == 0) {
             dmux_ = (PortClassifier*)TclObject::lookup(argv[2]);
             if (dmux_ == 0) {
                 fprintf(stderr, "%s: %s lookup of %s failed\n",
                     __FILE__,
                     argv[1],
                     argv[2]);
                 return TCL_ERROR;
             }
             return TCL_OK;
         } //printf("Starting our simulation");
             
	// Obtains corresponding tracer
        else if (strcmp(argv[1], "log-target") == 0 ||
             strcmp(argv[1], "tracetarget") == 0) {
             logtarget_ = (Trace*)TclObject::lookup(argv[2]);
             if (logtarget_ == 0)
                 return TCL_ERROR;
             return TCL_OK;
         }
	}
     
     else if(argc == 5)
     {
     		if(strcmp(argv[1],"lionkey")==0) {
		send_lion_key(atoi(argv[2]),atoi(argv[3]),atoi(argv[4]));
		return TCL_OK;
	}
		
	}
     
 			
     // Pass the command to the base class
     return Agent::command(argc, argv);
 }

void lion::recv(Packet *p,Handler *h)
{        struct hdr_cmn* ch            = HDR_CMN(p);
         struct hdr_ip* ih             = HDR_IP(p);
	 struct hdr_lion_pkt* ph=HDR_lion_PKT(p);
     	int v=ph->type_;
	if(v==0)
	{ 	
		recv_lion_hello(p);
		
	}
	else if(v==2)
	{
		recv_lion_key(p);
	}
	else if(v==1)
	{
	recv_lion_pkt(p);
	}
	else if(v==3)
	{
	recv_lion_path(p);
	}
	else if(v==4)
	{
	recv_froml2(p);
	}
	else if(v==5)
	{
	recv_lion1path(p);
	}
	else if(v==6)
	{
	recv_node1L2(p);
	}

}

void lion::global_deploy()
{
	int u=1;
	while(u!=(GK+1))
	{
		int k=rand()%10000;
		
		int z=compare(k,globalkey,u);
		if(!z)
		{
			globalkey[u]=k;
			u++;
		}
	}	
		printf("Printing Global Key Table\n");
		printf("\n-----------------------------------------------------------\n");
		for(int i=1;i<(GK+1);i++)
		{
			
			printf("\t%d",globalkey[i]);

		}
					printf("\n-----------------------------------------------------------\n");
	
}
int lion::compare(int k,int globalkey[],int u)
{
	for(int i=1;i<(GK+1);i++)
	
	if(k==globalkey[i])
	return 1;
	
	
return 0;
}

void lion::assignkey()
{
	int u,k;
	if(category()==0)
		u=L1K;
	else
		u=L2K;
	        
		k=rand()%1000;
		k++;	
		localkey[0][0]=k;
		localkey[1][0]=globalkey[k];
		
	for(int i=1;i<u;i++)
	{
		int k=rand()%1000;
		k++;
		if(check(k,localkey,i))
			i--;
		else
			{
				localkey[0][i]=k;
				localkey[1][i]=globalkey[k];
			}
			
	}

	/*if(category()==0)
	{
		printf("\n----------------------------------------------\n");
		for(int j=0;j<L1K;j++)
		{
printf("The L1 node local keys identifier=%d\n",localkey[0][j]);
			
		int l=localkey[0][j];
		printf("\t%d----------%d",localkey[0][j],localkey[1][j]);
printf("The corresponding global refer=%d\n",globalkey[l]);	 
		}
		printf("\n----------------------------------------------\n");
	}
	else
	{
		printf("\n----------------------------------------------\n");
		for(int k=0;k<L2K;k++)
		{
		
			printf("The L2 node local keys identifier=%d\n",localkey[0][k]);
			int g=localkey[0][k];
			printf("\t%d----------%d",localkey[0][k],localkey[1][k]);
			printf("The corresponding global refer=%d\n",globalkey[g]);

		}
		printf("\n----------------------------------------------\n");
	}*/
				
}

int lion::check(int k,int localkey[2][L2K],int u)
{
	for(int i=0;i<u;i++)
	if(k==localkey[0][i])
	return 1;
	
	
return 0;
}
		

 
void lion::pkeys()
{
//printf("^^^^^^^^^^^^^^^^^no of direct links are%d\n",cdlink);
//printf("^^^^^^^^^^^^^^^^no of indirect links are %d\n",cindlink);
}
void lion::printmatches(nsaddr_t source,nsaddr_t des,int match)
{
printf("The no of comman keys between  %d----%d  is %d\n",source,des,match);
} 


void lion::send_lion_hello() { 
	Packet* p                     = allocpkt();
       struct hdr_cmn* ch            = HDR_CMN(p);
       struct hdr_ip* ih             = HDR_IP(p);
	struct hdr_lion_pkt* ph=HDR_lion_PKT(p); 
	ph->pkt_x_=pkt_x();
         ph->pkt_y_=pkt_y();
	ph->type_=0;//type 0 indicates it is a hello packet
	ph->category_=category();
	//printf("x=%lf y=%lf",pkt_x(),pkt_y()); 
	
     ph->pkt_len          = 10;
      ph->pkt_seq_num      = seq_no_++;
      ph->ret=0;
        
      ch->ptype()            = PT_LION;
ph->pkt_src=ra_addr();

ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len;
ch->error()            = 0;
ch->next_hop()         = IP_BROADCAST;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            = IP_BROADCAST;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;

//printf("hello packet sentfrom=%d\n",ra_addr());
Scheduler::instance().schedule(target_, p,0.00 );
}

void lion::recv_lion_hello(Packet *p)
{
     struct hdr_cmn* ch = HDR_CMN(p);     
     struct hdr_ip* ih  = HDR_IP(p);
     struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	nsaddr_t des;
     double px,py,nx,ny;
     int hop; 
     int cat_;
     px=ph->pkt_x_;
     py=ph->pkt_y_;
     cat_=ph->category_;
	
nx=this->pkt_x();
ny=this->pkt_y();
des=ra_addr(); 

      assert(ih->sport() == RT_PORT);
      assert(ih->dport() == RT_PORT);
fprintf(stdout,"%f :packet transfered from %d to %d\n",CURRENT_TIME,ph->pkt_src,ra_addr()); 
 rtable_.add_entry(ph->pkt_src,des,hop,px,py,nx,ny,cat_,0,ph->pkt_src);
drop(p);
}

void lion::send_lion_pkt( ) {
      Packet* p                     = allocpkt();
       struct hdr_cmn* ch            = HDR_CMN(p);
       struct hdr_ip* ih             = HDR_IP(p);
	struct hdr_lion_pkt* ph=HDR_lion_PKT(p);
         ph->pkt_x_=pkt_x();
         ph->pkt_y_=pkt_y();
         ph->category_=category();
	ph->type_=1;//indicates type of 1
	int e;
	int u=0;
	if(category()==1)
		e=L2K;
	else
		e=L1K;		
		for(int i=0;i<e;i++)
	        {	
			ph->keyident[i]=localkey[0][i];		
			u++;		
		}
		
			
     //printf("x=%lf y=%lf",pkt_x(),pkt_y()); 

     ph->pkt_len          = 10;
      ph->pkt_seq_num      = seq_no_++;
      ph->ret=0;
      ch->ptype()            = PT_LION;
ph->pkt_src=ra_addr();
ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len;
ch->error()            = 0;
ch->next_hop()         = IP_BROADCAST;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            = IP_BROADCAST;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;
//printf("packet sent from=%d\n",ra_addr());
Scheduler::instance().schedule(target_, p,0.0 );
}

 

void lion::recv_lion_pkt(Packet* p) 
{
	struct hdr_cmn* ch = HDR_CMN(p);     
	struct hdr_ip* ih  = HDR_IP(p);
     	struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
     	nsaddr_t des;
     	double px,py,nx,ny;
	int k=0;		
     	int hop; 
	int match=0;
     	int curcat,pktcat;	
     	px=ph->pkt_x_;
     	py=ph->pkt_y_;
	nsaddr_t source=ph->pkt_src;
     	pktcat=ph->category_;
     	curcat=category();
     	int found=0;
	int e,f;
	int q,w;
	int temp_key[L2K];
	int u=0;
	if(pktcat==1)
	{
		e=L2K;
		//int temp_key[e];
		for(int i=0;i<e;i++)
		{
			temp_key[i]=ph->keyident[i];
			//u++;
		}
	}
	else
	{
	       e=L1K;
		//int temp_key[e];
		for(int i=0;i<e;i++)
		{
			temp_key[i]=ph->keyident[i];
			//u++;
		}
	}
	
	if(curcat==1)
	      f=L2K;
	else 
	    f=L1K;
	printf("------------%d NODE PACKET------------\n",ph->pkt_src);
			for(w=0;w<e;w++)
			{
	
	printf("\t%d",temp_key[w]);				
   			}
printf("----------------%d NODE-----------\n",ra_addr());
			for(q=0;q<f;q++)
			{
			printf("\t%d",localkey[0][q]);
			}	
			for(w=0;w<e;w++)
			{
			
				for(q=0;q<f;q++)
				{

				
					if(localkey[0][q] == temp_key[w])
					{
					
						match++;
					
					}
					
				}
				
			}
	         
//printf("The no of matches is %d called by %d\n",match,ra_addr());	
		
		for(int i=0;i<e;i++)
		{
			
			//int g=ph->keyident[i];
			//printf("Iteration %d\n",i);
			for(int j=0;j<f;j++)
			{
				
				
				if(localkey[0][j] == temp_key[i])
				{					     						found=1;
					k=localkey[1][j];
					break;
			//printf("the keys are %d\n",ck[s++]);
					
				}
					
			}
			if(found)
				break;
			
	         }
	      
			

//printf("x=%lf y=%lf category=%d ",px,py,cat_);
nx=this->pkt_x();
ny=this->pkt_y();
//des = ra_addr;
des=ra_addr();
printmatches(source,des,match); 
//printf("inside recieve\n");
// if(ph->ret==1&&des!=ra_addr_)

    assert(ih->sport() == RT_PORT);
    assert(ih->dport() == RT_PORT);
drop(p);
Tcl::instance().evalf("$ns after [expr 10 + %d] \"[$node(%d) agent 255] lionkey %d %d %d\"",some++,des, source,k,match);

}
					      
void lion::send_lion_key( nsaddr_t src,int k,int match) 
{

	Packet* p                     = allocpkt();
       struct hdr_cmn* ch            = HDR_CMN(p);
       struct hdr_ip* ih             = HDR_IP(p);
	struct hdr_lion_pkt* ph=HDR_lion_PKT(p); 
	ph->matchno=match;
	ph->pkt_src=ra_addr();
	ph->key=k;
	ph->type_=2;
	ph->category_=category();
	ph->pkt_len          = 10;
      ph->pkt_seq_num      = seq_no_++;
      ph->ret=0;
        
      ch->ptype()            = PT_LION;
ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len;
ch->error()            = 0;
ch->next_hop()         = src;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            =  src;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;
Scheduler::instance().schedule(target_, p,0.0 );
}
	 



void lion::recv_lion_key(Packet *p) 
{

	struct hdr_cmn* ch = HDR_CMN(p);     
        struct hdr_ip* ih  = HDR_IP(p);
        struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	int rkey=ph->key;
	int matchkeys=ph->matchno;
	if(category()==1)
	{
		for(int j=0;j<L2K;j++)
		{
			if(localkey[1][j]==rkey)
			{
			//printf("Updating routing table of %d\n",ph->pkt_src);		
			//matchkeys=matchkeys+1;
			rtable_.add_ackentry(ph->pkt_src,1,matchkeys);	
			cdlink++;
			break;
			}
			//printf("Received %d as common key\n",rkey);
			
				
		}
	}	
	else
	{		
	for(int i=0;i<L1K;i++)
	{
		
		if(localkey[1][i] == rkey)
		{
			rtable_.add_ackentry(ph->pkt_src,1,matchkeys);	
			cdlink++;
			break;
		} 
	
		//printf("Received %d as common key\n",rkey);
	}
	
}	
drop(p);
}	
 
void lion::send_lion_path()
{
		Packet*  p                   = allocpkt();
         	struct hdr_cmn* ch            = HDR_CMN(p);
         	struct hdr_ip* ih             = HDR_IP(p);
	  	struct hdr_lion_pkt* ph=HDR_lion_PKT(p);
	 	ph->pkt_src=ra_addr(); 
		ph->type_=3;
		int q=rtable_.space_nolink(ph->pkt_src);
		cindlink=cindlink+q;
		int m=rtable_.space_L2link(ra_addr());
	if(m==0||q==0)
	{
		drop(p);
	}
	else
	{
	nsaddr_t array_nolink[q];
	nsaddr_t send_L2node[m];
	ph->number_L2node=m;
	ph->number_nolink=q;
	//printf("the corresponding number of vacant spaces available for l2 node=%d\n",ph->number_L2node);
	//printf("the number of nodes whose status is 0 is=%d\n",ph->number_nolink);
        rtable_.check_gateway(ra_addr(),array_nolink,q);
        rtable_.check_L2node(ra_addr(),send_L2node,m);
        int j=0,z=0;  
	int i=0;      
	                	
		for(i=0;i<q;i++)
		{

	 		ph->send_addr[i]=array_nolink[i];
			ph->verify_addr[0][i]=array_nolink[i];
			ph->verify_addr[1][i]=0;
		
			printf("The corresponding %d node which does not have link with  %d\n",ph->pkt_src,array_nolink[i]);
		}
			

		 ph->pkt_len          = 10;
      		ph->pkt_seq_num      = seq_no_++;
      	ph->ret=0;
        
      ch->ptype()            = PT_LION;
      ch->direction()        = hdr_cmn::DOWN;
      ch->size()             = IP_HDR_LEN + ph->pkt_len;
       ch->error()            = 0;
	
	ch->addr_type()        = NS_AF_INET;
	ih->saddr()            = ra_addr();
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;

	 
	ch->next_hop()=send_L2node[j];
	ih->daddr()= send_L2node[j];

	//for(i=0;i<q;i++)
	//printf("the %d  l1 node id is sent to %d l2 node\n",array_nolink[i],send_L2node[j]);
	Scheduler::instance().schedule(target_, p,0.1 );
	if(j!=m)
		{
			
			j++;
			//printf("the value of %d\n",j);
			Packet*  p1                   = allocpkt();
         		struct hdr_cmn* ch1            = HDR_CMN(p1);
         		struct hdr_ip* ih1             = HDR_IP(p1);
	  		struct hdr_lion_pkt* ph1=HDR_lion_PKT(p1);
	 		ph1->pkt_src=ra_addr(); 
	 	    	
		for(i=0;i<q;i++)
		{

	 		ph1->send_addr[i]=array_nolink[i];
			ph1->verify_addr[0][i]=array_nolink[i];	
			ph1->verify_addr[1][i]=0;
			
			
		}
			
	 	
			ph1->type_=3;
			ph1->pkt_len          = 10;
      			ph1->pkt_seq_num      = seq_no_++;
      			ph1->ret=0;
      		 
      			ch1->ptype()            = PT_LION;
      			ch1->direction()        = hdr_cmn::DOWN;
      			ch1->size()             = IP_HDR_LEN + ph->pkt_len;
       			ch1->error()            = 0;
	
ch1->addr_type()        = NS_AF_INET;
ih1->saddr()            = ra_addr();
ih1->sport()            = RT_PORT;
ih1->dport()            = RT_PORT;
ih1->ttl()              = IP_DEF_TTL;

	 
	ch1->next_hop()=send_L2node[j];
	ih1->daddr()= send_L2node[j];
	Scheduler::instance().schedule(target_, p1,0.1 );
	//for(i=0;i<q;i++)
	//printf("the %d  l1 node id is sent to %d l2 node\n",array_nolink[i],send_L2node[j]);

}
}	//printf("The L2 nodes to which the lion pkt is sent %d\n",ch->next_hop()); 
}



//printf("lion path packet sent from=%d\n",ra_addr());*/


void lion::recv_lion_path(Packet *p)
{
 	struct hdr_cmn* ch = HDR_CMN(p);     
     	struct hdr_ip* ih  = HDR_IP(p);
	struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	nsaddr_t src;
	src=ph->pkt_src;
	int n,i,match;
	n=ph->number_nolink;
	nsaddr_t copy_addr[2][8];
	for(i=0;i<n;i++)
	{
	
    		nsaddr_t temp;
		temp=ph->send_addr[i];
		int match=rtable_.retmatch(temp);		
		int k=rtable_.verify_link(temp);
		if(k==1)
		ph->verify_addr[1][i]=match;
		//printf("The match is %d\n",match);
	}
	
	for(int s=0;s<n;s++)
	{
		
		copy_addr[0][s]=ph->verify_addr[0][s];
		copy_addr[1][s]=ph->verify_addr[1][s];
		printf("%d node has %d matches\n",copy_addr[0][s],copy_addr[1][s]);
		
	}
	
	assert(ih->sport() == RT_PORT);
        assert(ih->dport() == RT_PORT);
	drop(p);
	send_froml2(src,copy_addr,n);
	
}
void lion::send_froml2(nsaddr_t des,nsaddr_t copy_addr[2][8],int n)
{
	        Packet*  p                   = allocpkt();
         	struct hdr_cmn* ch            = HDR_CMN(p);
         	struct hdr_ip* ih             = HDR_IP(p);
	  	struct hdr_lion_pkt* ph=HDR_lion_PKT(p);
		int s;
		for(s=0;s<n;s++)
		{
		
		ph->verify_addr[0][s]=copy_addr[0][s];
		ph->verify_addr[1][s]=copy_addr[1][s];
		printf("I am sending to %d with %d match bw %d & %d \n",des,ph->verify_addr[1][s],ra_addr_,copy_addr[0][s]);
		}
				ph->type_=4;
				ph->number_nolink=n;
				
				ph->pkt_src=ra_addr();	
				ph->pkt_len          = 10;
      				ph->pkt_seq_num      = seq_no_++;
      				ph->ret=0;
      				ch->ptype()            = PT_LION;
     		 		ch->direction()        = hdr_cmn::DOWN;
      				ch->size()             = IP_HDR_LEN + ph->pkt_len;
       				ch->error()            = 0;
				ch->addr_type()        = NS_AF_INET;
				ih->saddr()            = ra_addr();
				ch->next_hop()=des;
				ih->daddr()= des;
				ih->sport()            = RT_PORT;
				ih->dport()            = RT_PORT;
				ih->ttl()              = IP_DEF_TTL;
				Scheduler::instance().schedule(target_, p,0.1);
		
}

void lion::recv_froml2(Packet *p)
{
 	struct hdr_cmn* ch = HDR_CMN(p);     
     	struct hdr_ip* ih  = HDR_IP(p);
	struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	int n=ph->number_nolink;
	int s;
	for(s=0;s<n;s++)
	{
		
	printf("%d recieved %d matches from %d L2\n",ra_addr_,ph->verify_addr[1][s],ph->pkt_src);
	rtable_.check_valid(ra_addr(),ph->verify_addr[0][s],ph->pkt_src,ph->verify_addr[1][s]);
}
	assert(ih->sport() == RT_PORT);
        assert(ih->dport() == RT_PORT);
	//printf("printing the new routing table of%d \n",ra_addr());
	drop(p);
		
}

void lion::send_lion1path()
{
		Packet*  p                   = allocpkt();
         	struct hdr_cmn* ch            = HDR_CMN(p);
         	struct hdr_ip* ih             = HDR_IP(p);
	  	struct hdr_lion_pkt* ph=HDR_lion_PKT(p);	
		ph->type_=5;
       		ph->pkt_src=ra_addr();
		int q=rtable_.node_with1key(ra_addr());
		//printf("NODE 1 LINK=%d\n",q);
		int m=rtable_.space_L2link(ra_addr());
	if(m==0||q==0)
	{
		drop(p);
	}
	else
	{
	nsaddr_t node_1key[q];
	ph->number_1key=q;
        rtable_.check_1keymatch(ra_addr(),node_1key,q);
	nsaddr_t send_L2node[m];
	ph->number_L2node=m;
        rtable_.check_L2node(ra_addr(),send_L2node,m);
        int j=0,z=0;  
	int i=0;      
	                	
		for(i=0;i<q;i++)
		{

	 		ph->send_addr[z]=node_1key[i];
			ph->verify_addr[0][z]=node_1key[i];
			ph->verify_addr[1][z]=0;
			z++;
			printf("The corresponding %d node which does not have link with  %d\n",ph->pkt_src,node_1key[i]);
		}
			

		 ph->pkt_len          = 10;
      		ph->pkt_seq_num      = seq_no_++;
      	ph->ret=0;
        
      ch->ptype()            = PT_LION;
      ch->direction()        = hdr_cmn::DOWN;
      ch->size()             = IP_HDR_LEN + ph->pkt_len;
       ch->error()            = 0;
	
	ch->addr_type()        = NS_AF_INET;
	ih->saddr()            = ra_addr();
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;

	 
	ch->next_hop()=send_L2node[j];
	ih->daddr()= send_L2node[j];

	//for(i=0;i<q;i++)
	//printf("the %d  l1 node id is sent to %d l2 node\n",node_1key[i],send_L2node[j]);
	Scheduler::instance().schedule(target_, p,0.1 );
	if(j!=m)
		{
			
			j++;
			//printf("the value of %d\n",j);
			Packet*  p1                   = allocpkt();
         		struct hdr_cmn* ch1            = HDR_CMN(p1);
         		struct hdr_ip* ih1             = HDR_IP(p1);
	  		struct hdr_lion_pkt* ph1=HDR_lion_PKT(p1);
	 		ph1->pkt_src=ra_addr(); 
	 		int z=0;    	
		for(i=0;i<q;i++)
		{

	 		ph1->send_addr[z]=node_1key[i];
			ph1->verify_addr[0][z]=node_1key[i];	
			ph1->verify_addr[1][z]=0;
			z++;
			
		}
			
	 	
			ph1->type_=5;
			ph1->pkt_len          = 10;
      			ph1->pkt_seq_num      = seq_no_++;
      			ph1->ret=0;
      		 
      			ch1->ptype()            = PT_LION;
      			ch1->direction()        = hdr_cmn::DOWN;
      			ch1->size()             = IP_HDR_LEN + ph->pkt_len;
       			ch1->error()            = 0;
	
ch1->addr_type()        = NS_AF_INET;
ih1->saddr()            = ra_addr();
ih1->sport()            = RT_PORT;
ih1->dport()            = RT_PORT;
ih1->ttl()              = IP_DEF_TTL;

	 
	ch1->next_hop()=send_L2node[j];
	ih1->daddr()= send_L2node[j];
	Scheduler::instance().schedule(target_, p1,0.1 );
	//for(i=0;i<q;i++)
	//printf("the %d  l1 node id is sent to %d l2 node\n",node_1key[i],send_L2node[j]);

}
}	
}
void lion::recv_lion1path(Packet *p) 
{

	struct hdr_cmn* ch = HDR_CMN(p);     
        struct hdr_ip* ih  = HDR_IP(p);
        struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	nsaddr_t source;
	source=ph->pkt_src;
	int key1=rtable_.retmatch(ph->pkt_src);
	int q=ph->number_1key;
	nsaddr_t copy_addr[2][8];		
	for(int j=0;j<q;j++)
	{
		nsaddr_t temp=ph->send_addr[j];
		int k=rtable_.verify_link(temp);
		if(k==1)
		{
			int key2=rtable_.retmatch(temp);
			int key=key1+key2;
			ph->verify_addr[1][j]=key;
		}
	}
	int h=0;
	for(int i=0;i<q;i++)
	{
		copy_addr[0][h]=ph->verify_addr[0][i];
		copy_addr[1][h]=ph->verify_addr[1][i];
		h++;
	}

	assert(ih->sport() == RT_PORT);
        assert(ih->dport() == RT_PORT);
	drop(p);	
	send_node1L2(source,copy_addr,q);

}
void lion::send_node1L2(nsaddr_t source,nsaddr_t copy_addr[2][8],int q)
{
		Packet*  p                   = allocpkt();
         	struct hdr_cmn* ch            = HDR_CMN(p);
         	struct hdr_ip* ih             = HDR_IP(p);
	  	struct hdr_lion_pkt* ph=HDR_lion_PKT(p);	
		ph->pkt_src=ra_addr();
		ph->type_=6;
		int z=0,s;
		for(s=0;s<q;s++)
		{
		
		ph->verify_addr[0][z]=copy_addr[0][s];
		ph->verify_addr[1][z]=copy_addr[1][s];
		//printf("%d -------%d\n",copy_addr[0][s],copy_addr[1][s]);
		z++;
		}
		ph->pkt_len          = 10;
      		ph->pkt_seq_num      = seq_no_++;
      		ph->ret=0;
      		 
      		ch->ptype()            = PT_LION;
      		ch->direction()        = hdr_cmn::DOWN;
      		ch->size()             = IP_HDR_LEN + ph->pkt_len;
       		ch->error()            = 0;
	ph->number_1key=q;
	ch->addr_type()        = NS_AF_INET;
	ih->saddr()            = ra_addr();
	ch->next_hop()=source;
	ih->daddr()= source;
	
	ih->sport()            = RT_PORT;
	ih->dport()            = RT_PORT;
	ih->ttl()              = IP_DEF_TTL;
	Scheduler::instance().schedule(target_, p,0.1);
}
void lion::recv_node1L2(Packet *p)
{
	struct hdr_cmn* ch = HDR_CMN(p);     
        struct hdr_ip* ih  = HDR_IP(p);
        struct hdr_lion_pkt* ph = HDR_lion_PKT(p);
	int n=ph->number_1key;
	nsaddr_t L2src=ph->pkt_src;
	for(int i=0;i<n;i++)
	{
		nsaddr_t des=ph->verify_addr[0][i];
		int key=ph->verify_addr[1][i];
		rtable_.updatetable(ra_addr(),L2src,des,key);
	}
	assert(ih->sport() == RT_PORT);
        assert(ih->dport() == RT_PORT);
	//printf("printing the new routing table of%d \n",ra_addr());
	drop(p);
}
void lion::sum_keys()
{
	rtable_.total_keys(ra_addr());
}
