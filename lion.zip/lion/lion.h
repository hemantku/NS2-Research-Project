#ifndef _lion_h_
#define _lion_h_
#include <packet.h>
#include <agent.h>
#include <trace.h>
#include <timer-handler.h>
#include <random.h>
#include <classifier-port.h>
#include "lion_pkt.h"
#include "lion_rtable.h"
#define CURRENT_TIME          Scheduler::instance().clock()
#define L1K 30
#include <timer-handler.h>
#define L2K 600
#define GK 1000


class lion;                //forward declaration
class lion_PktTimer :public TimerHandler{
public:

    lion_PktTimer(lion* agent) : TimerHandler() {
         agent_ = agent;
    }
protected:
    lion*    agent_;
    virtual void expire(Event* e);
};



/*class lion_keytimer:public TimerHandler{
public:

    lion_keytimer(lion* agent) : TimerHandler() {
         agent_ = agent;
	
    }
protected:
    lion*    agent_;
    virtual void expire(Event* e);
};*/
/* Agent */
class lion: public Agent {
/* Friends */
    friend class lion_PktTimer;
    //friend class lion_keytimer;
/* Private members*/

private:

    double x_;
    double y_;
    int category_;//to determine which type of packet either 0 or1
    int localkey[2][L2K];
    int nhop;
    int pkt_hop;
    nsaddr_t           ds_addr_;
    nsaddr_t           ra_addr_;
    lion_PktTimer 	pkt_timer_;
    //lion_keytimer       pkt_timer1_;
   nsaddr_t		index_; 
   int 			seq_no_;
	
    
    int                state_;
    lion_rtable   rtable_;
    int                accessible_var_;
    
	
protected:
    PortClassifier*    dmux_;      // For passing packets up to agents.
    Trace* logtarget_; // For logging.
    //lion_PktTimer        pkt_timer_; // Timer for sending packets.
    	void  recv_lion_pkt(Packet*);
	void recv_lion_hello(Packet*);
	void recv_lion_key(Packet*);	
	void recv_lion_path(Packet*);
	void recv_froml2(Packet*);	
	void send_lion_hello( );
	void send_lion_key( nsaddr_t,int,int);
    	void  send_lion_pkt();
    	void send_lion_path();
    	void printmatches(nsaddr_t,nsaddr_t,int);    
	void pkeys();
    	void send_froml2(nsaddr_t ,nsaddr_t [2][8],int);
	void send_lion1path();
	void recv_lion1path(Packet*);
	void send_node1L2(nsaddr_t,nsaddr_t[2][8],int);
	void recv_node1L2(Packet*);
	void sum_keys();	
    inline nsaddr_t&        ra_addr_index();
    inline double& pkt_x() {return x_;}
    inline double& pkt_y() {return y_;}
    inline int& category() {return category_;}   				 			
    inline int& ra_addr() {return ra_addr_;}  

 
public:
    lion(nsaddr_t);
    //void show_category();
    void global_deploy();		
    int   command(int, const char*const*);
    void recv(Packet*, Handler*);
        int compare(int,int[GK],int);
    void assignkey();				
   	
   int check(int,int[2][L2K],int);

		
};
#endif
