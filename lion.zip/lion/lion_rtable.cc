
#include <object.h>
#include <agent.h>
#include <trace.h>
#include <packet.h>
#include <scheduler.h>
#include <random.h>

#include <mac.h>
#include <ll.h>
#include <cmu-trace.h>
#include  <classifier-port.h>

#include<packet.h>
#include "lion_pkt.h"
#include "lion.h"
#include "lion_rtable.h"
//int numnode;
int sum;

 lion_rtable::lion_rtable() {rt_.count=0;}

    void lion_rtable::print(_IO_FILE* out) {
    printf("Printing Routing table............\n");
       fprintf(out, "\ndestination\nsource\t\tx\t\ty\tdistance\tcategory status\tnhop\tkeymatches\n");
        for (int i=0;i<rt_.count;i++) {
       //if (rt_.ent[i].src!=0)
      //{
	//printf("the value of rt_.count=%d\n",rt_.count);
fprintf(out, "\n%d\n%d\t %f\t %f\t%f\t%d\t%d\t%d\t%d\n",
          rt_.ent[i].dest,rt_.ent[i].src,rt_.ent[i].x,rt_.ent[i].y,rt_.ent[i].dist,rt_.ent[i].cat_,rt_.ent[i].t,rt_.ent[i].nhop,rt_.ent[i].key);
     // }     
}
 }

nsaddr_t lion_rtable::ret_node(int i)
{
	return rt_.ent[i].src;
}

int lion_rtable::ret_count()
{
	//printf("\n--%d--\n",rt_.count);
	return rt_.count;
}

   void lion_rtable::clear() {

      for(int i=0;i<=5;i++)
	{ 
		rt_.ent[i].src=0;
		rt_.ent[i].x=0;
		rt_.ent[i].y=0;
 	}
			      }


void lion_rtable::add_entry(nsaddr_t dest,nsaddr_t src,int y,double px,double py,double nx,double ny,int cat,int sta,nsaddr_t hop) {
rt_.ent[rt_.count].dest=src;
rt_.ent[rt_.count].src=dest;
rt_.ent[rt_.count].x=px;
rt_.ent[rt_.count].y=py;
rt_.ent[rt_.count].cat_=cat;
rt_.ent[rt_.count].dist=distance(px,py,nx,ny);
//printf("entry updated for=%d in routing table",dest);
rt_.ent[rt_.count].t=sta;
rt_.ent[rt_.count].nhop=hop;
rt_.ent[rt_.count].key=0;
rt_.count++;
}


void lion_rtable::add_ackentry(nsaddr_t nei,int x,int matchkeys)
{

	int j;
		for(j=0;j<rt_.count;j++)
	{
		if(rt_.ent[j].src==nei)
		{
			//printf("Before updation for node %d status is %d\n",rt_.ent[j].src,rt_.ent[j].t);
			rt_.ent[j].key=matchkeys;
			
			rt_.ent[j].t=x;
			//printf("After Updation for node %d changed status to %d\n",rt_.ent[j].src,rt_.ent[j].t);
			
			
			break;
		}
	}
	
}


double lion_rtable::distance(double px,double py, double nx, double ny)
{
	double res;
	res=sqrt(((nx-px)*(nx-px))+((ny-py)*(ny-py)));
	return res;
}
int lion_rtable::space_nolink(nsaddr_t src)
{
	int i,d;
	d=0;
	
			for(i=0;i<rt_.count;i++)
			{
				if(rt_.ent[i].t==0)
				{
					d++;
				}
			}		
				return d;
			
	

}	
int lion_rtable::space_L2link(nsaddr_t src)//previous code
{
	int i,d;
	 d=0;
			for(i=0;i<rt_.count;i++)
			{
				if(rt_.ent[i].cat_==1)
				{		
					d++;
				}
			}
			return d;
		
}



void lion_rtable::check_gateway(nsaddr_t src,nsaddr_t array_nolink[],int q)
{
	//printf("i am in the check gateway function\n");
	//int i;
	int i,j=0;
	
	for(i=0;i<rt_.count;i++)
	{
		if(rt_.ent[i].t==0)
				{
				array_nolink[j]=rt_.ent[i].src;
				//printf("The corresponding link lacking value is %d\n",array_nolink[j]);
				j++;
				}	
 	}
}	

void lion_rtable::check_L2node(nsaddr_t src,nsaddr_t send_L2node[],int m)
{	int i,j=0;
	for(i=0;i<rt_.count;i++)
	{
		if(rt_.ent[i].cat_==1)
		{
			send_L2node[j]=rt_.ent[i].src;
                        //printf("the L2 nodes are %d\n",send_L2node[j]);
                        j++;
		}
		
	}
	
}
int lion_rtable::verify_link(nsaddr_t temp)
{ 
	//printf("i am in verify link function\n");
	int i;
	for(i=0;i<rt_.count;i++)
	{
		if((rt_.ent[i].src==temp)&&(rt_.ent[i].t==1))
		{
			return 1;
		}
	
	}
	return 0;
}
void lion_rtable::check_valid(nsaddr_t raddr,nsaddr_t k,nsaddr_t L2src,int match)
{
int i,key;
for(i=0;i<rt_.count;i++)
	{
		if(rt_.ent[i].src==L2src)
		{  
			key=rt_.ent[i].key;
		}
	}
for(i=0;i<rt_.count;i++)
{
			
		if((rt_.ent[i].src==k)&&(rt_.ent[i].t==0)&&(match!=0))
		{	int avg=(key+match)/2;
			rt_.ent[i].t=1;
//printf("%d is calling %d thru %d with %d and %d\n",raddr,k,L2src,match,key);
			rt_.ent[i].key=avg;
			rt_.ent[i].nhop=L2src;
	
			
		}
	
}
	
}
void lion_rtable::total_keys(nsaddr_t temp)
{
	int tablekey=0; 
	for(int i=0;i<rt_.count;i++)
	{
		tablekey=tablekey+rt_.ent[i].key;
	}
	sum=sum+tablekey;
	printf("The %d node has the following keys %d\n",temp,tablekey);
	printf("The total key is %d\n",sum);
}	
int lion_rtable::retmatch(nsaddr_t temp)
{
	int i,keys;
	for(i=0;i<rt_.count;i++)
	{
		if(rt_.ent[i].src==temp)
		{
			
			keys=rt_.ent[i].key;
			printf("KEYS ARE %d FOR %d\n",keys,temp);
			return keys;
		}
	}
}
int lion_rtable::node_with1key(nsaddr_t src)
{
	int i,node1=0,j;//node1 is count to know how many nodes has exactly 				//one key match
	
			for(i=0;i<rt_.count;i++)
			{
				if(rt_.ent[i].key==1||rt_.ent[i].key==2)
				{
					node1++;
				}
			}		
				return node1;
		
}
void lion_rtable::check_1keymatch(nsaddr_t temp,nsaddr_t node_1key[],int q)
{
	int i,j=0;
	for(i=0;i<rt_.count;i++)
	{
		if(rt_.ent[i].key==1||rt_.ent[i].key==2)
		{
			node_1key[j]=rt_.ent[i].src;
                        j++;
		}
	}
}
void lion_rtable::updatetable(nsaddr_t temp,nsaddr_t L2src,nsaddr_t des,int key)
{
	int i;
	for(i=0;i<rt_.count;i++)
	{
		if((rt_.ent[i].src==des)&&(rt_.ent[i].key==1||rt_.ent[i].key==2))
		{
			int w=(key/2);
			rt_.ent[i].nhop=L2src;
			rt_.ent[i].key=w;
		}
	}
}

   u_int32_t lion_rtable::size() {
     return rt_.count;
 }


