#include <object.h>
#include <agent.h>
#include <trace.h>
#include <packet.h>
#include <scheduler.h>
#include <random.h>
#include <address.h>
#include <mac.h>
#include <ll.h>
#include <cmu-trace.h>
#include  <classifier-port.h>

#include<packet.h>
#include "protoname_pkt.h"
#include "protoname.h"
#include "protoname_rtable.h"
int counter=0;

int hdr_protoname_pkt::offset_;
static class ProtonameHeaderClass : public PacketHeaderClass {
public:
ProtonameHeaderClass() : PacketHeaderClass("PacketHeader/Protoname",sizeof(hdr_protoname_pkt)) {
        bind_offset(&hdr_protoname_pkt::offset_);
    }
} class_rtProtoProtoname_hdr;
  

   static class ProtonameClass : public TclClass {
 public:
     ProtonameClass() : TclClass("Agent/Protoname") {}
     TclObject* create(int argc, const char*const* argv) {
         assert(argc == 5);
    return (new Protoname((nsaddr_t)atoi(argv[4])));
     }
 } class_rtProtoProtoname;



   void
   Protoname_PktTimer::expire(Event* e) {
     agent_->send_protoname_pkt();
     //agent_->reset_protoname_pkt_timer();
 }

   Protoname::Protoname(nsaddr_t id) : Agent(PT_PROTONAME), pkt_timer_(this) {
	printf("%d\n",id);
    bind_bool("accessible_var_", &accessible_var_);
	bind("X_",&x_);
	bind("Y_",&y_);
	bind("n_energy_",&n_energy_);
	bind("parent_",&parent_);
	bind_bool("treenode_",&treenode_);
	bind("k_",&k_);
    ra_addr_ = id;
    hop_=0;
}


    int Protoname::command(int argc, const char*const* argv) {
      if (argc == 2) {
          if (strcasecmp(argv[1], "start") == 0) {
              pkt_timer_.resched(0.0);
              return TCL_OK;
          }
	  
	else if ( strcasecmp(argv[1],"tree_node") == 0)
	{		
		Tcl::instance().resultf("%d",treenode());
		return TCL_OK;
	}
	else if ( strcasecmp(argv[1],"kval") == 0)
	{		
		Tcl::instance().resultf("%d",k());
		return TCL_OK;
	}
	else if ( strcasecmp(argv[1],"parent_node") == 0)
	{		
		Tcl::instance().resultf("%d",parent());
		return TCL_OK;
	}
	else if ( strcasecmp(argv[1],"gmax1") == 0)
	{	
		
		Tcl::instance().resultf("%f",gmax1());
		return TCL_OK;
	}
	else if ( strcasecmp(argv[1],"gmax2") == 0)
	{	
		
		Tcl::instance().resultf("%f",gmax2());
		return TCL_OK;
	}
	else if ( strcasecmp(argv[1],"energy_node") == 0)
	{		
		Tcl::instance().resultf("%f",n_energy());
		return TCL_OK;
	}
	
          else if (strcasecmp(argv[1], "print_rtable") == 0) {
              if (logtarget_ != 0) {
                fprintf(stdout, "P %f _%d_ Routing Table\t",
                     CURRENT_TIME,
                     ra_addr());
                 logtarget_->pt_->dump();
                 ccccc
             }
             else {
           fprintf(stdout, "%f _%d_ If you want to print this routing table "
                    "you must create a trace file in your tcl script",
                     CURRENT_TIME,
                     ra_addr());
             }
             return TCL_OK;
         }
     }
     else if (argc == 3) {
         // Obtains corresponding dmux to carry packets to upper layers
         if (strcmp(argv[1], "port-dmux") == 0) {
             dmux_ = (PortClassifier*)TclObject::lookup(argv[2]);
             if (dmux_ == 0) {
                 fprintf(stderr, "%s: %s lookup of %s failed\n",
                     __FILE__,
                     argv[1],
                     argv[2]);
                 return TCL_ERROR;
             }
             return TCL_OK;
         }
	else if (strcasecmp(argv[1],"construct_tree")== 0)
		{
			for(int k=0;k<5000;k++)
			{
				if(!chkenergy(atoi(argv[2])))
					break;
			for(int i=0;i<(atoi(argv[2])-4);i++)
			{
				tree(atoi(argv[2]));
				//
			}
			printf("\nNext %d\n",counter);
				for(int j=0;j<atoi(argv[2]);j++)
				{
				Tcl::instance().evalf("[$node(%d) agent 255] set treenode_ 0",j);
				Tcl::instance().evalf("[$node(%d) agent 255] set k_ %d",j,((int)Random::uniform()% 8)+1);
				}
				Tcl::instance().evalf("[$node(0) agent 255] set treenode_ 1");
				Tcl::instance().evalf("[$node(1) agent 255] set treenode_ 1");
				Tcl::instance().evalf("[$node(2) agent 255] set treenode_ 1");
				Tcl::instance().evalf("[$node(3) agent 255] set treenode_ 1");
				counter++;
			}	
			printf("Nuber of queries satisfied=%d",counter);
			printenergy(atoi(argv[2]));
			/*int count=rtable_.ret_count();
			for(int i=0;i<count;i++)			
			{
				nsaddr_t neigh=rtable_.ret_node(i);
				Tcl::instance().evalf("[$node(%d) agent 255] tree_node",neigh);
				if(atoi(Tcl::instance().result())==0)
				{
					printf("%d is included\n",neigh);
					Tcl::instance().evalf("[$node(%d) agent 255] set treenode_ 1",neigh);
					Tcl::instance().evalf("[$node(%d) agent 255] construct_tree",neigh);
					
				} 
			}
			double maximum=0;
			int a=0;
			for (int i=0;i<atoi(argv[2]);i++)
			{
			Tcl::instance().evalf("[$node(%d) agent 255] tree_node",i);
				if(atoi(Tcl::instance().result())==0)
				{
					//printf("Callinf gmax for node %d\n",i);
					Tcl::instance().evalf("[$node(%d) agent 255] gmax",i);
					double newmax=atof(Tcl::instance().result());
					if (maximum < newmax )
					{
						maximum=newmax;
						a=i;
						//printf(" \n U R IDIOT %d",a);
					}	
				}
			
			}
//			gmax();
			printf("\ni am added %d via ",a);
			Tcl::instance().evalf("[$node(%d) agent 255] set treenode_ 1",a);
			Tcl::instance().evalf("[$node(%d) agent 255] parent_node",a);
			printf("%d",atoi(Tcl::instance().result()));
			Tcl::instance().evalf("[$node(%d) agent 255] set n_energy_ %f",a,maximum);
			
			k_update(a);*/
			return TCL_OK;
		}
	else if (strcmp(argv[1], "distance") == 0 )
	{
		double res;
		res=rtable_.lookup(atoi(argv[2]));
		Tcl::instance().resultf("%f",res);
		return TCL_OK;
         }
         // Obtains corresponding tracer
         else if (strcmp(argv[1], "log-target") == 0 ||
             strcmp(argv[1], "tracetarget") == 0) {
             logtarget_ = (Trace*)TclObject::lookup(argv[2]);
             if (logtarget_ == 0)
                 return TCL_ERROR;
             return TCL_OK;
         }
     }
     // Pass the command to the base class
     return Agent::command(argc, argv);
 }
int
 Protoname::chkenergy(int nodes) {
	for (int i=0;i<nodes;i++)
	{
		Tcl::instance().evalf("[$node(%d) agent 255] energy_node",i);
		if(atoi(Tcl::instance().result())<=0)
		return 0; 		
	}
	return 1;
}
void
 Protoname::tree(int nodes) {
double maximum=0;
double newmax;
			int a=-1;
			for (int i=0;i<nodes;i++)
			{
			Tcl::instance().evalf("[$node(%d) agent 255] tree_node",i);
				if(atoi(Tcl::instance().result())==0)
				{
					//printf("Callinf gmax for node %d\n",i);
					Tcl::instance().evalf("[$node(%d) agent 255] gmax1",i);
					double newmax1=atof(Tcl::instance().result());
					Tcl::instance().evalf("[$node(%d) agent 255] gmax2",i);
					double newmax2=atof(Tcl::instance().result());
					Tcl::instance().evalf("[$node(%d) agent 255] gmax1",i);
					double newmax3=atof(Tcl::instance().result());
					Tcl::instance().evalf("[$node(%d) agent 255] gmax2",i);
					double newmax4=atof(Tcl::instance().result());
					if((newmax1>newmax2) && (newmax1>newmax3) && (newmax1>newmax4))
						newmax=newmax1;
					else if((newmax2>newmax1) && (newmax2>newmax3) && (newmax2>newmax4))
						newmax=newmax2;
					else if((newmax3>newmax1) && (newmax3>newmax2) && (newmax3>newmax4))
						newmax=newmax3;
					else
						newmax=newmax4;
							
					//double newmax=(newmax1>newmax2)?newmax1:newmax2;
					if (maximum < newmax )
					{
						maximum=newmax;
						a=i;
						//printf(" \n U R IDIOT %d",a);
					}	
				}
			
			}
//			gmax();
			if(a!=-1)
			{
			printf("\ni am added %d via ",a);
			Tcl::instance().evalf("[$node(%d) agent 255] set treenode_ 1",a);
			Tcl::instance().evalf("[$node(%d) agent 255] parent_node",a);
			printf("%d",atoi(Tcl::instance().result()));
			//Tcl::instance().evalf("[$node(%d) agent 255] set n_energy_ %f",a,maximum);
			k_update(a);
			}
			else
			{
			printf("There is a problem");
			counter--;
			return;
			}
}	
void Protoname::printenergy(int nodes) {
	for (int i=0;i<nodes;i++)
	{
		Tcl::instance().evalf("[$node(%d) agent 255] energy_node",i);
		printf("%d -> %d\n",i,atoi(Tcl::instance().result()));
	}
}
    void
 Protoname::recv(Packet* p, Handler* h) {
       struct hdr_cmn* ch = HDR_CMN(p);
       struct hdr_ip* ih   = HDR_IP(p);

       if (ih->saddr() == ra_addr()) {
           // If there exists a loop, must drop the packet
           if (ch->num_forwards() > 0) {
               drop(p, DROP_RTR_ROUTE_LOOP);
              return;
          }
          // else if this is a packet I am originating, must add IP header
          else if (ch->num_forwards() == 0)
              ch->size() += IP_HDR_LEN;
      }

      // If it is a protoname packet, must process it
      if (ch->ptype() == PT_PROTONAME)
          recv_protoname_pkt(p);
      // Otherwise, must forward the packet (unless TTL has reached zero)
  else {
         // forward_data(p);
          ih->ttl_--;
          if (ih->ttl_ == 0) 
              drop(p, DROP_RTR_TTL);
              return;
          }

          //forward_data(p);
      }
 }



   void
 Protoname::recv_protoname_pkt(Packet* p) {
struct hdr_cmn* ch = HDR_CMN(p);     
struct hdr_ip* ih  = HDR_IP(p);
     struct hdr_protoname_pkt* ph = HDR_PROTONAME_PKT(p);
  nsaddr_t des;
double px,py,nx,ny;
  int hop; 
px=ph->pkt_x_;
py=ph->pkt_y_;
nx=this->x();
ny=this->y();
des = ph->pkt_src(); 
hop=ph->pkt_hop(); 
 if(ph->ret()==1&&des!=ra_addr())
{
      assert(ih->sport() == RT_PORT);
      assert(ih->dport() == RT_PORT);
fprintf(stdout,"%f :packet transfered from %d to %d\n",CURRENT_TIME,ph->pkt_src(),ra_addr());
 rtable_.add_entry(des,hop,px,py,nx,ny);
 Packet::free(p);
 }
else
{      
  Packet *pa =allocpkt(); 
        ch            = HDR_CMN(pa);
        ih             = HDR_IP(pa);
        ph = HDR_PROTONAME_PKT(pa);
       ph->pkt_src()          = ra_addr();
       ph->pkt_len()          = 7;
      ph->pkt_seq_num()      = seq_num_++;
      ph->ret()=1;
ph->pkt_x()= x_;
	ph->pkt_y()=y_;    
      ph->pkt_hop()=hop++; 
ch->ptype()            = PT_PROTONAME;
ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len();
ch->error()            = 0;
ch->next_hop()         = IP_BROADCAST;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            = des;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;
Scheduler::instance().schedule(target_, pa, JITTER);
//Scheduler::instance().schedule(target_, p, JITTER);
/*

Packet *pb =allocpkt(); 
        ch   = HDR_CMN(pb);
        ih   = HDR_IP(pb);
        ph = HDR_PROTONAME_PKT(pb);
       ph->pkt_src()          = des;
       ph->pkt_len()          = 7;
      ph->pkt_seq_num()      = seq_num_++;
      ph->ret()=1;     
//ph->pkt_x()= this->x();
//	ph->pkt_y()=this->y();
      ph->pkt_hop()=hop++; 
ch->ptype()            = PT_PROTONAME;
ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len();
ch->error()            = 0;
ch->next_hop()         = IP_BROADCAST;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            = ra_addr()+1;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;
Scheduler::instance().schedule(target_, pb, JITTER);*/



}
}



    void
 Protoname::send_protoname_pkt() {
      Packet* p                     = allocpkt();
       struct hdr_cmn* ch            = HDR_CMN(p);
       struct hdr_ip* ih             = HDR_IP(p);
       struct hdr_protoname_pkt* ph = HDR_PROTONAME_PKT(p);
       ph->pkt_src()          = ra_addr();
       ph->pkt_len()          = 20;
      ph->pkt_seq_num()      = seq_num_++;
	ph->pkt_x()= this->x();
	ph->pkt_y()=this->y();
      ph->ret()=0;
      ph->pkt_hop()=1;  
ch->ptype()            = PT_PROTONAME;
ch->direction()        = hdr_cmn::DOWN;
ch->size()             = IP_HDR_LEN + ph->pkt_len();
ch->error()            = 0;
ch->next_hop()         = IP_BROADCAST;
ch->addr_type()        = NS_AF_INET;
ih->saddr()            = ra_addr();
ih->daddr()            = IP_BROADCAST;
ih->sport()            = RT_PORT;
ih->dport()            = RT_PORT;
ih->ttl()              = IP_DEF_TTL;
Scheduler::instance().schedule(target_, p, JITTER);
}

 void
 Protoname::reset_protoname_pkt_timer() {
      pkt_timer_.resched((double)5.0);
 }



 /*   void
 Protoname::forward_data(Packet* p) {
       struct hdr_cmn* ch = HDR_CMN(p);
       struct hdr_ip* ih = HDR_IP(p);
      if (ch->direction() == hdr_cmn::UP &&
((u_int32_t)ih->daddr() == IP_BROADCAST || ih->daddr() == ra_addr())) {
    fprintf(stdout,"%f :thee packet transfered from %d\n",CURRENT_TIME,ra_addr());
     dmux_->recv(p,(Handler*)0);
           return;
      }
      else {
          ch->direction() = hdr_cmn::DOWN;
          ch->addr_type() = NS_AF_INET;
          if ((u_int32_t)ih->daddr() == IP_BROADCAST)
              ch->next_hop() = IP_BROADCAST;
          else {
              nsaddr_t next_hop = rtable_.lookup(ih->daddr());
              if (next_hop == IP_BROADCAST) {
              debug("%f: Agent %d can not forward a packet destined to %d\n",
                     CURRENT_TIME,ra_addr(),ih->daddr());
          drop(p, DROP_RTR_NO_ROUTE);
          return;
      }
      else
          ch->next_hop() = next_hop;
  }
  Scheduler::instance().schedule(target_, p, 0.0);
}
}*/
double Protoname :: g(int v, int u)
{
	double min=99999999.0;
	double re;
		Tcl::instance().evalf("[$node(%d) agent 255] set parent_ %d",v,u);
	while (1)
	{
		Tcl::instance().evalf("[$node(%d) agent 255] energy_node",v);
		double ne=atof(Tcl::instance().result());
		
		Tcl::instance().evalf("[$node(%d) agent 255] parent_node",v);
		int p=atoi(Tcl::instance().result());
		Tcl::instance().evalf("[$node(%d) agent 255] kval",v);
		int k=atoi(Tcl::instance().result());
		Tcl::instance().evalf("[$node(%d) agent 255] distance %d",v,p);
		double d=atof(Tcl::instance().result());
		//printf(" dist is %f and %f", d,ne-d);
		re=ne-(k*d*d);
		if(min>re)
		{
		min=re;
		
		}
		v=p;
		if(v==0)
		{
		break;
		}
	}
	//printf("i am b4 b4 idiot %f\n",min);
	return min;
}
double Protoname :: gmax1()
{
	double max=-1;
	int count=rtable_.ret_count();
	//printf("\nCount is %d",count);
	//for(int i=0;i<count;i++)
	//{
		//Tcl::instance().evalf("[$node(%d) agent 255] tree_node",i);
		//if(atoi(Tcl::instance().result())==1)
		
		for(int i=0;i<count;i++)			
		{
			int neigh=rtable_.ret_node(i);
			//printf("\nIIIII%dIIIIII",neigh);
			Tcl::instance().evalf("[$node(%d) agent 255] tree_node",neigh);
			if(atoi(Tcl::instance().result())==1)
			{
			double gm=g(this->ra_addr(),neigh);
			if(gm>max)
			{
				max=gm;
				Tcl::instance().evalf("[$node(%d) agent 255] set parent_ %d",this->ra_addr(),neigh);
			}
			}
		}
	
		//printf("i am b4 idiot %f\n",max);
		
		return max;
}
double Protoname :: gmax2()
{
	double max=-1;
	int count=rtable_.ret_count();
	//printf("\nCount is %d",count);
	//for(int i=0;i<count;i++)
	//{
		//Tcl::instance().evalf("[$node(%d) agent 255] tree_node",i);
		//if(atoi(Tcl::instance().result())==1)
		
		for(int i=0;i<count;i++)			
		{
			int neigh=rtable_.ret_node(i);
			//printf("\nIIIII%dIIIIII",neigh);
			Tcl::instance().evalf("[$node(%d) agent 255] tree_node",neigh);
			if(atoi(Tcl::instance().result())==1)
			{
			double gm=g(this->ra_addr(),neigh);
			if(gm>max)
			{
				max=gm;
				Tcl::instance().evalf("[$node(%d) agent 255] set parent_ %d",this->ra_addr(),neigh);
			}
			}
		}
	
		//printf("i am b4 idiot %f\n",max);
		
		return max;
}



void Protoname::k_update(int a)
{
	double re;	
	Tcl::instance().evalf("[$node(%d) agent 255] kval",a);
	int temp=atoi(Tcl::instance().result());
	while(1)
	{
	Tcl::instance().evalf("[$node(%d) agent 255] parent_node",a);
	int p=atoi(Tcl::instance().result());
	Tcl::instance().evalf("[$node(%d) agent 255] distance %d",a,p);
		double d=atof(Tcl::instance().result());
	re=(temp*d*d);
	Tcl::instance().evalf("[$node(%d) agent 255] energy_node",a);
		double ne=atof(Tcl::instance().result());
	ne=ne-re;
	
	Tcl::instance().evalf("[$node(%d) agent 255] set n_energy_ %f",a,ne);
	a=p;
	if(a==0)
		break;
	}
}

                                                           

























