#ifndef __protoname_h__
#define __protoname_h__
#include  "protoname_pkt.h"
#include  <agent.h>
#include  <packet.h>
#include  <trace.h>
#include  <timer-handler.h>
#include  <random.h>
#include  <classifier-port.h>
#include "protoname_rtable.h"
#define CURRENT_TIME          Scheduler::instance().clock()
#define JITTER                (Random::uniform()*0.1)
class Protoname;              // forward declaration
/* Timers */
class Protoname_PktTimer : public TimerHandler {
public:
    Protoname_PktTimer(Protoname* agent) : TimerHandler() {
         agent_ = agent;
    }
protected:
    Protoname*    agent_;
    virtual void expire(Event* e);
};
/* Agent */
class Protoname : public Agent {
    /* Friends */
    friend class Protoname_PktTimer;
    /* Private members */
private:
    double x_;
    double y_;
    int hop_;
    nsaddr_t ds_addr_;
    nsaddr_t           ra_addr_;
    nsaddr_t		parent_;
    double n_energy_;
    int treenode_;
    int                state_;
    protoname_rtable   rtable_;
    int                accessible_var_;
    u_int8_t           seq_num_;
	int 	k_;
protected:
    PortClassifier*    dmux_;      // For passing packets up to agents.
    Trace*             logtarget_; // For logging.
  Protoname_PktTimer pkt_timer_; // Timer for sending packets.
 inline nsaddr_t&        ra_addr()        { return ra_addr_; }
 inline int&             hop()          { return hop_; }
 inline int&             accessible_var() { return accessible_var_; }
 inline nsaddr_t& ds_addr() {return ds_addr_;}
 inline double& n_energy() {return n_energy_;}
 inline double& x() {return x_;}
 inline double& y() {return y_;}
inline int& k() {return k_;}
 inline int& treenode() {return treenode_;}
inline int& parent() {return parent_;}
    void  forward_data(Packet*);
    void  recv_protoname_pkt(Packet*);
    void  send_protoname_pkt();
    void  reset_protoname_pkt_timer();
	double gmax1();
	double gmax2();
void tree(int);
	void printenergy(int);
	int chkenergy(int);
	double g(int,int);
	void k_update(int);
public:
    Protoname(nsaddr_t);
    int   command(int, const char*const*);
    void recv(Packet*, Handler*);
  
};
#endif
